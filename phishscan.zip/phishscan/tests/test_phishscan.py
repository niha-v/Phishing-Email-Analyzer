from pathlib import Path

import pytest

from phishscan import analyze, parse_email
from phishscan.checks import levenshtein, lookalike_brand
from phishscan.parser import base_domain
from phishscan.report import defang_url

SAMPLES = Path(__file__).resolve().parent.parent / "samples"


@pytest.mark.parametrize("name,verdict", [
    ("phish_sample.eml", "LIKELY PHISHING"),
    ("suspicious_sample.eml", "SUSPICIOUS"),
    ("legit_sample.eml", "LIKELY BENIGN"),
])
def test_sample_verdicts(name, verdict):
    assert analyze(parse_email(SAMPLES / name)).verdict == verdict


def test_phish_key_findings():
    titles = {f.title for f in analyze(parse_email(SAMPLES / "phish_sample.eml")).findings}
    for expected in ["DMARC fail", "Link text doesn't match destination",
                     "Double file extension", "Lookalike sender domain", "Link to raw IP address"]:
        assert expected in titles


def test_decoy_anchor_text_not_an_ioc():
    result = analyze(parse_email(SAMPLES / "phish_sample.eml"))
    assert "https://www.paypal.com/signin" not in result.iocs["urls"]
    assert "gmail.com" not in result.iocs["domains"]


@pytest.mark.parametrize("host,brand", [
    ("paypa1-secure.xyz", "paypal"),
    ("micros0ft-login.com", "microsoft"),
    ("secure-docusign.com", "docusign"),
    ("paypal.xyz", "paypal"),
])
def test_lookalikes_detected(host, brand):
    assert lookalike_brand(host) == brand


@pytest.mark.parametrize("host", ["www.paypal.com", "login.microsoftonline.com", "github.com", "firstbank.com"])
def test_legit_domains_not_flagged(host):
    assert lookalike_brand(host) is None


def test_helpers():
    assert base_domain("a.b.login.paypal.com") == "paypal.com"
    assert base_domain("shop.amazon.co.uk") == "amazon.co.uk"
    assert levenshtein("paypal", "paypall") == 1
    assert defang_url("http://evil.xyz/a.php") == "hxxp://evil[.]xyz/a.php"
