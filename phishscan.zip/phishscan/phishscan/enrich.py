"""Optional threat-intel enrichment using the VirusTotal v3 API."""
from __future__ import annotations

import base64
import json
import time
import urllib.error
import urllib.request

from .analyzer import AnalysisResult
from .checks import Finding

VT_BASE = "https://www.virustotal.com/api/v3"


def _vt_get(path: str, api_key: str) -> dict | None:
    req = urllib.request.Request(f"{VT_BASE}/{path}", headers={"x-apikey": api_key})
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            return json.load(resp)
    except urllib.error.HTTPError as err:
        if err.code == 404:
            return None  # never seen by VirusTotal
        raise


def _stats(data: dict | None) -> dict | None:
    if not data:
        return None
    return data.get("data", {}).get("attributes", {}).get("last_analysis_stats")


def enrich_with_virustotal(result: AnalysisResult, api_key: str,
                           delay: float = 15.0, max_lookups: int = 8) -> None:
    """Look up attachment hashes and URLs. The free API allows 4 requests/minute,
    so a delay is applied between calls."""
    targets = [("file", a["sha256"], a["filename"]) for a in result.iocs["attachments"]]
    targets += [("url", u, u) for u in result.iocs["urls"]]
    targets = targets[:max_lookups]

    for i, (kind, value, label) in enumerate(targets):
        if i:
            time.sleep(delay)
        try:
            if kind == "file":
                stats = _stats(_vt_get(f"files/{value}", api_key))
            else:
                url_id = base64.urlsafe_b64encode(value.encode()).decode().rstrip("=")
                stats = _stats(_vt_get(f"urls/{url_id}", api_key))
        except Exception as exc:  # network / quota errors shouldn't kill the run
            result.enrichment[label] = {"error": str(exc)}
            continue

        result.enrichment[label] = stats or {"status": "not found"}
        if stats and (stats.get("malicious", 0) or stats.get("suspicious", 0)):
            mal, sus = stats.get("malicious", 0), stats.get("suspicious", 0)
            result.add_finding(Finding(
                "threat-intel", "high" if mal >= 3 else "medium",
                f"VirusTotal detections for {kind}",
                f"{label}: {mal} malicious, {sus} suspicious engine verdicts."))
